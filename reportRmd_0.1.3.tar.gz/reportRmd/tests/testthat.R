library(testthat)
library(reportRmd)

test_check("reportRmd")
