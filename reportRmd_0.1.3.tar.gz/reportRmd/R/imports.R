# Package Imports for NAMESPACE ----
# This file declares imports from base R packages to satisfy R CMD check

#' @importFrom stats confint confint.default glm qt terms var
#' @importFrom graphics strheight
#' @importFrom grDevices dev.size
NULL
